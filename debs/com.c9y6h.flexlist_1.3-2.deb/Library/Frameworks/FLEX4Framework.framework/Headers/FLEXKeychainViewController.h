//
//  FLEXKeychainViewController.h
//  FLEX
//
//  Created by ray on 2019/8/17.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "FLEXGlobalsEntry.h"
#import "FLEXFilteringTableViewController.h"

@interface FLEXKeychainViewController : FLEXFilteringTableViewController <FLEXGlobalsEntry>

@end
