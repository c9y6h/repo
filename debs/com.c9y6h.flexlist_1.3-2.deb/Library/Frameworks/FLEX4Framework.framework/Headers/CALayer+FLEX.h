//
//  CALayer+FLEX.h
//  FLEX
//
//  Created by Tanner on 2/28/20.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

@interface CALayer (FLEX)

@property (nonatomic) BOOL flex_continuousCorners;

@end
