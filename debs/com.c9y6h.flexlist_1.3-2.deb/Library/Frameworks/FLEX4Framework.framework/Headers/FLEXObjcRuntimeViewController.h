//
//  FLEXObjcRuntimeViewController.h
//  FLEX
//
//  Created by Tanner on 3/23/17.
//  Copyright © 2017 Tanner Bennett. All rights reserved.
//

#import "FLEXTableViewController.h"
#import "FLEXGlobalsEntry.h"

@interface FLEXObjcRuntimeViewController : FLEXTableViewController <FLEXGlobalsEntry>

@end
