//
//  FLEXBookmarksViewController.h
//  FLEX
//
//  Created by Tanner on 2/6/20.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "FLEXTableViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface FLEXBookmarksViewController : FLEXTableViewController

@end

NS_ASSUME_NONNULL_END
