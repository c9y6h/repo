//
//  FLEXAddressExplorerCoordinator.h
//  FLEX
//
//  Created by Tanner Bennett on 7/10/19.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "FLEXGlobalsEntry.h"

@interface FLEXAddressExplorerCoordinator : NSObject <FLEXGlobalsEntry>

@end
