//
//  FLEXKeychainTableViewController.h
//  FLEX
//
//  Created by ray on 2019/8/17.
//  Copyright © 2019 Flipboard. All rights reserved.
//

#import "FLEXGlobalsEntry.h"
#import "FLEXTableViewController.h"

@interface FLEXKeychainTableViewController : FLEXTableViewController <FLEXGlobalsEntry>

@end
